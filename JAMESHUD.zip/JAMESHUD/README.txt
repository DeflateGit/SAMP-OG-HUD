You need to install latest CLEO & Silent ASI Loader from https://github.com/cleolibrary/CLEO5/releases or use one which i added in archive.
1. Place all files in root directory where is gta_sa.exe "modloader,GTA_IV_HUD,modloader.asi" after that place the SACLEO files into the root directory.
2. Start SAMP and enjoy the new HUD! I already show at Shadow Complex & NGRP (James Rothschild)