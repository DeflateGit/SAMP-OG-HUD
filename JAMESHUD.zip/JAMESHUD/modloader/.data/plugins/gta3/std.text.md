gta3.std.text
=========================================================================
 + __Author__:   LINK/2012 (<dma_2012@hotmail.com>)
 + __Priority__: 50
 + __Game__: III, Vice City, San Andreas

*************************************************************************

__Description__:
 This plugin is responsible for handling text files, that is:
  
  * GTA Text Files  (gxt)
  * Fake Text Files (fxt)

